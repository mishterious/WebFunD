

var one = 5;
var two = -10;
var three = 12.27;
var four = 1200;

var stringOne = "fuck year it works!";
var stringTwo = "Always try hard, on each test and life itself";
var stingThree = "Drop anything that gets me out of its way."

var totally = true;
var fucked = false;

var undefinted;

console.log(one + " is a number and so are " + two + three + four);
